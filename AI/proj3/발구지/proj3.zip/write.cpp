#include<iostream>
using namespace std;
int main(void){
  double num = 91787974;
  for(double i=0;i<num;i++){
    cout<<""<<endl;
  }
  return 0;
}